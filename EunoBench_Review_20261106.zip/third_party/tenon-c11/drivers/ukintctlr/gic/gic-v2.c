/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Authors: Wei Chen <Wei.Chen@arm.com>
 *          Jianyong Wu <Jianyong.Wu@arm.com>
 *
 * Copyright (c) 2018, Arm Ltd. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
#include <string.h>
#include <libfdt.h>
#include <uk/essentials.h>
#include <uk/print.h>
#include <uk/assert.h>
#include <uk/bitops.h>
#include <uk/asm.h>
#include <uk/arch/limits.h>
#include <uk/plat/lcpu.h>
#ifdef CONFIG_UKPLAT_ACPI
#include <uk/plat/common/acpi.h>
#endif /* CONFIG_UKPLAT_ACPI */
#include <uk/intctlr.h>
#include <uk/intctlr/limits.h>
#include <uk/ofw/fdt.h>
#include <uk/plat/common/bootinfo.h>
#include <uk/plat/lcpu.h>
#include <uk/plat/spinlock.h>

#include <arm/cpu.h>
#include <uk/intctlr/gic-v2.h>

/* Max CPU interface for GICv2 */
#define GIC_MAX_CPUIF		8

#define GIC_MAX_IRQ		UK_INTCTLR_MAX_IRQ

#define GIC_CPU_REG(gdev, r)	((void *)(gdev.cpuif_mem_addr + (r)))

#ifdef CONFIG_HAVE_SMP
__spinlock gicv2_dist_lock;
#endif /* CONFIG_HAVE_SMP */

/** GICv2 driver */
struct _gic_dev gicv2_drv = {
	.version        = GIC_V2,
	.is_present     = 0,
	.is_probed      = 0,
	.is_initialized = 0,
	.dist_mem_addr  = 0,
	.dist_mem_size  = 0,
	.cpuif_mem_addr = 0,
	.cpuif_mem_size = 0,
#ifdef CONFIG_HAVE_SMP
	.dist_lock      = &gicv2_dist_lock,
#endif /* CONFIG_HAVE_SMP */
};

static const char * const gic_device_list[] __maybe_unused = {
	"arm,cortex-a15-gic",
	"arm,gic-400",
	NULL
};

/* Inline functions to access GICC & GICD registers */
static inline void write_gicd8(uint64_t offset, uint8_t val)
{
	ioreg_write8(GIC_DIST_REG(gicv2_drv, offset), val);
}

static inline void write_gicd32(uint64_t offset, uint32_t val)
{
	ioreg_write32(GIC_DIST_REG(gicv2_drv, offset), val);
}

static inline uint32_t read_gicd32(uint64_t offset)
{
	return ioreg_read32(GIC_DIST_REG(gicv2_drv, offset));
}

static inline void write_gicc32(uint64_t offset, uint32_t val)
{
	ioreg_write32(GIC_CPU_REG(gicv2_drv, offset), val);
}

static inline uint32_t read_gicc32(uint64_t offset)
{
	return ioreg_read32(GIC_CPU_REG(gicv2_drv, offset));
}

/* Functions of GIC CPU interface */

/** Enable GIC CPU interface */
static void gicv2_enable_cpuif(void)
{
	/* just set bit 0 to 1 to enable CPU interface */
	write_gicc32(GICC_CTLR, GICC_CTLR_ENABLE);
}

/**
 * Set priority threshold for processor. Only interrupts with higher priority
 * than this threshold are signaled to the processor
 *
 * @param priority priority threshold [0..255]. The GIC implementation
 *    may not support all levels. For example, if only 128 levels are supported
 *    every two levels (e.g., 0 and 1) map to the same effective value
 */
static void gicv2_set_threshold_priority(uint32_t priority)
{
	/* GICC_PMR allocate 1 byte for each IRQ */
	UK_ASSERT(priority <= GICC_PMR_PRIO_MAX);
	write_gicc32(GICC_PMR, priority);
}

/**
 * Acknowledge IRQ and retrieve highest priority pending interrupt
 *
 * @return the ID of the signaled interrupt in bits [0..9] and for SGIs in
 *    a multiprocessor system the originating CPU's ID in bits [10..12]
 */
static uint32_t gicv2_ack_irq(void)
{
	return read_gicc32(GICC_IAR);
}

/**
 * Signal completion of interrupt processing.
 *
 * NOTE: If GICC_CTLR.EOImode is set to 1 this performs a priority drop for
 *    the specified interrupt.
 *
 * @param eoir acknowledge register value with bits [0..9] indicating the
 *    ID of the interrupt to complete and for SGIs in a multiprocessor system
 *    the ID of the CPU that requested the interrupt in bits [10..12]. Must
 *    correspond to the last value read with ack_irq()
 */
static void gicv2_eoi_irq(uint32_t eoir)
{
	write_gicc32(GICC_EOIR, eoir);
}

/* Functions of GIC Distributor */

/**
 * Generate a Software Generated Interrupt (SGI)
 *
 * @param sgintid the software generated interrupt id
 * @param send_to_all
 * true sending sgi to all cores in the system except "self".
 * false sending sgi to the specified core.
 * @param cpuid
 * This parametr work only when `send_to_all` is false.
 * @return zero on success
 */
static int gicv2_sgi_gen(uint8_t sgintid, bool send_to_all,
						 uint32_t cpuid __maybe_unused)
{
	unsigned long flags __maybe_unused;
	uint8_t				targetlist	 = 0;
	uint32_t			sgi_register = 0;

	UK_ASSERT(sgintid <= GICD_SGI_MAX_INITID);
	/* Set SGI INITID field */
	sgi_register = sgintid;

	if (send_to_all) {
		sgi_register |= GICD_SGI_FILTER_ALL << GICD_SGI_FILTER_SHIFT;
		goto write_gicd_sgir;
	}

	if (cpuid == lcpu_get_current()->physical_id) {
		sgi_register |= GICD_SGI_FILTER_SELF << GICD_SGI_FILTER_SHIFT;
		goto write_gicd_sgir;
	}

	sgi_register |= GICD_SGI_FILTER_LIST << GICD_SGI_FILTER_SHIFT;
	targetlist = tnplat_lcpu_physical_index(cpuid);
	/* Set SGI targetlist field */
	sgi_register |= (targetlist & GICD_SGI_TARGET_MASK)
					<< GICD_SGI_TARGET_SHIFT;

write_gicd_sgir:
	dist_lock(gicv2_drv, flags);
	write_gicd32(GICD_SGIR, sgi_register);
	dist_unlock(gicv2_drv, flags);
	return 0;
}

/**
 * Set target CPU for an interrupt
 *
 * @param irq interrupt number [GIC_SPI_BASE..GIC_MAX_IRQ]
 * @param targetlist an 8-bit bitmap with 1 bit per CPU 0-7. A `1` bit
 *    indicates that the SGI should be forwarded to the respective CPU
 */
static void gicv2_set_irq_target(uint32_t irq, uint32_t targetlist)
{
	UK_ASSERT(irq >= GIC_SPI_BASE && irq <= GIC_MAX_IRQ);
	UK_ASSERT(targetlist <= __U8_MAX);
	unsigned long flags __maybe_unused;

	dist_lock(gicv2_drv, flags);
	write_gicd8(GICD_ITARGETSR(irq), (uint8_t)targetlist);
	dist_unlock(gicv2_drv, flags);
}

/**
 * Set priority for an interrupt
 *
 * @param irq interrupt number [0..GIC_MAX_IRQ]
 * @param priority priority [0..255]. The GIC implementation may not support
 *    all levels. For example, if only 128 levels are supported every two levels
 *    (e.g., 0 and 1) map to the same effective value. Lower values correspond
 *    to higher priority
 */
static void gicv2_set_irq_prio(uint32_t irq, uint8_t priority)
{
	UK_ASSERT(irq <= GIC_MAX_IRQ);
	UK_ASSERT(priority < (1 << (8 - TRANS_PRIORITY_SHIFT)));
	unsigned long flags __maybe_unused;

	dist_lock(gicv2_drv, flags);
	write_gicd8(GICD_IPRIORITYR(irq), priority << TRANS_PRIORITY_SHIFT);
	dist_unlock(gicv2_drv, flags);
}

/**
 * Enable an interrupt
 *
 * @param irq interrupt number [0..GIC_MAX_IRQ]
 */
static void gicv2_enable_irq(uint32_t irq)
{
	UK_ASSERT(irq <= GIC_MAX_IRQ);
	unsigned long flags __maybe_unused;

	dist_lock(gicv2_drv, flags);
	write_gicd32(GICD_ISENABLER(irq), UK_BIT(irq % GICD_I_PER_ISENABLERn));
	dist_unlock(gicv2_drv, flags);
}

/**
 * Disable an interrupt
 *
 * @param irq interrupt number [0..GIC_MAX_IRQ]
 */
static void gicv2_disable_irq(uint32_t irq)
{
	UK_ASSERT(irq <= GIC_MAX_IRQ);
	unsigned long flags __maybe_unused;

	dist_lock(gicv2_drv, flags);
	write_gicd32(GICD_ICENABLER(irq), UK_BIT(irq % GICD_I_PER_ICENABLERn));
	dist_unlock(gicv2_drv, flags);
}

/** Enable distributor */
static void gicv2_enable_dist(void)
{
	unsigned long flags __maybe_unused;

	/* just set bit 0 to 1 to enable distributor */
	dist_lock(gicv2_drv, flags);
	write_gicd32(GICD_CTLR, read_gicd32(GICD_CTLR) | GICD_CTLR_ENABLE);
	dist_unlock(gicv2_drv, flags);
}

/** Disable distributor */
static void gicv2_disable_dist(void)
{
	unsigned long flags __maybe_unused;

	/* just clear bit 0 to disable distributor */
	dist_lock(gicv2_drv, flags);
	write_gicd32(GICD_CTLR, read_gicd32(GICD_CTLR) & (~GICD_CTLR_ENABLE));
	dist_unlock(gicv2_drv, flags);
}


/**
 * Config trigger type for an interrupt
 *
 * @param irq interrupt number [GIC_PPI_BASE..GIC_MAX_IRQ]
 * @param trigger trigger type (UK_INTCTLR_IRQ_TRIGGER_*)
 */
static
void gicv2_set_irq_trigger(uint32_t irq, enum uk_intctlr_irq_trigger trigger)
{
	uint32_t val, mask, oldmask;
	unsigned long flags __maybe_unused;

	UK_ASSERT(irq >= GIC_PPI_BASE && irq <= GIC_MAX_IRQ);
	UK_ASSERT(trigger == UK_INTCTLR_IRQ_TRIGGER_EDGE ||
		  trigger == UK_INTCTLR_IRQ_TRIGGER_LEVEL);

	dist_lock(gicv2_drv, flags);

	val = read_gicd32(GICD_ICFGR(irq));
	mask = oldmask = (val >> ((irq % GICD_I_PER_ICFGRn) * 2)) &
			GICD_ICFGR_MASK;

	if (trigger == UK_INTCTLR_IRQ_TRIGGER_LEVEL) {
		mask &= ~GICD_ICFGR_TRIG_MASK;
		mask |= GICD_ICFGR_TRIG_LVL;
	} else if (trigger == UK_INTCTLR_IRQ_TRIGGER_EDGE) {
		mask &= ~GICD_ICFGR_TRIG_MASK;
		mask |= GICD_ICFGR_TRIG_EDGE;
	}

	/* Check if nothing changed */
	if (mask == oldmask)
		goto EXIT_UNLOCK;

	/* Update new interrupt type */
	val &= (~(GICD_ICFGR_MASK << (irq % GICD_I_PER_ICFGRn) * 2));
	val |= (mask << (irq % GICD_I_PER_ICFGRn) * 2);
	write_gicd32(GICD_ICFGR(irq), val);

EXIT_UNLOCK:
	dist_unlock(gicv2_drv, flags);
}

static void gicv2_handle_irq(struct __regs *regs)
{
	uint32_t stat, irq;

	do {
		stat = gicv2_ack_irq();
		irq = stat & GICC_IAR_INTID_MASK;

		/* Ensure interrupt processing starts only after ACK */
		isb();

		if (irq <= GIC_MAX_IRQ) {
			uk_intctlr_irq_handle(regs, irq);
			gicv2_eoi_irq(stat);
			continue;
		}

		/* EoI should only be signaled for non-spurious interrupts */
		if (irq != GICC_IAR_INTID_SPURIOUS)
			gicv2_eoi_irq(stat);

		break;
	} while (1);
}

tn_intctlr_trap_register(gicv2_handle_irq);

static void gicv2_init_dist(void)
{
	uint32_t val, cpuif_number, irq_number;
	uint32_t i;

	/* Turn off distributor */
	gicv2_disable_dist();

	/* Get GIC CPU interface */
	val = read_gicd32(GICD_TYPER);
	cpuif_number = GICD_TYPER_CPUI_NUM(val);
	if (cpuif_number > GIC_MAX_CPUIF)
		cpuif_number = GIC_MAX_CPUIF;
	uk_pr_info("GICv2 Max CPU interface:%d\n", cpuif_number);

	/* Get the maximum number of interrupts that the GIC supports */
	irq_number = GICD_TYPER_LINE_NUM(val);
	if (irq_number > GIC_MAX_IRQ)
		irq_number = GIC_MAX_IRQ + 1;
	uk_pr_info("GICv2 Max interrupt lines:%d\n", irq_number);

	/* Set all SPI's interrupt target to all CPUs */
	for (i = GIC_SPI_BASE; i < irq_number; i += GICD_I_PER_ITARGETSRn)
		write_gicd32(GICD_ITARGETSR(i), GICD_ITARGETSR_DEF);

	/* Set all SPI's interrupt type to be level-sensitive */
	for (i = GIC_SPI_BASE; i < irq_number; i += GICD_I_PER_ICFGRn)
		write_gicd32(GICD_ICFGR(i), GICD_ICFGR_DEF_TYPE);

	/* Set all SPI's priority to a default value */
	for (i = GIC_SPI_BASE; i < irq_number; i += GICD_I_PER_IPRIORITYn)
		write_gicd32(GICD_IPRIORITYR(i), GICD_IPRIORITY_DEF);

	/* Deactivate and disable all SPIs */
	for (i = GIC_SPI_BASE; i < irq_number; i += GICD_I_PER_ICACTIVERn) {
		write_gicd32(GICD_ICACTIVER(i), GICD_DEF_ICACTIVERn);
		write_gicd32(GICD_ICENABLER(i), GICD_DEF_ICENABLERn);
	}

	/* Turn on distributor */
	gicv2_enable_dist();

	uk_pr_info("GICv2 distributor initialized.\n");
}

static void gicv2_init_cpuif(void)
{
	uint32_t i;

	/* Set priority threshold to the lowest to make all IRQs visible to
	 * the CPU interface. Note: Higher priority corresponds to a lower
	 * priority field value.
	 */
	gicv2_set_threshold_priority(GICC_PMR_PRIO_MAX);

	/* Set PPI and SGI to the default value */
	for (i = 0; i < GIC_SPI_BASE; i += GICD_I_PER_IPRIORITYn)
		write_gicd32(GICD_IPRIORITYR(i), GICD_IPRIORITY_DEF);

	/* Deactivate SGIs and PPIs as the state is unknown at boot */
	write_gicd32(GICD_ICACTIVER(0), GICD_DEF_ICACTIVERn);
	write_gicd32(GICD_ICENABLER(0), GICD_DEF_PPI_ICENABLERn);

	/* Enable all SGIs */
	write_gicd32(GICD_ISENABLER(0), GICD_DEF_SGI_ISENABLERn);

	/* Enable CPU interface */
	gicv2_enable_cpuif();

	isb();

	uk_pr_info("GICv2 CPU interface initialized.\n");
}


/**
 * Initialize GICv2
 * NOTE: First time must not be called from multiple CPUs in parallel
 *
 * @return 0 on success, a non-zero error otherwise
 */
static int gicv2_initialize(void)
{
#ifdef CONFIG_HAVE_SMP
	if (gicv2_drv.is_initialized) {
		/* GIC is already initialized, we just need to initialize
		 * the CPU interface
		 */
		gicv2_init_cpuif();
		return 0;
	}
#endif /* CONFIG_HAVE_SMP */

	gicv2_drv.is_initialized = 1;

	/* Initialize GICv2 distributor */
	gicv2_init_dist();

	/* Initialize GICv2 CPU interface */
	gicv2_init_cpuif();

	return 0;
}

static void gicv2_set_ops(void)
{
	struct _gic_operations drv_ops = {
		.initialize		 = gicv2_initialize,
		.ack_irq		 = gicv2_ack_irq,
		.eoi_irq		 = gicv2_eoi_irq,
		.enable_irq		 = gicv2_enable_irq,
		.disable_irq	 = gicv2_disable_irq,
		.set_irq_trigger = gicv2_set_irq_trigger,
		.set_irq_prio	 = gicv2_set_irq_prio,
#if defined(CONFIG_LIBUKINTCTLR_TEST) || defined(CONFIG_LIBUKTEST_ALL)
		.get_irq_prio	  = NULL,
		.simulate_spi	  = NULL,
		.get_spi_affinity = NULL,
#endif
		.set_irq_affinity = gicv2_set_irq_target,
		.handle_irq		  = gicv2_handle_irq,
		.gic_sgi_gen	  = gicv2_sgi_gen,
	};

	/* Set driver functions */
	gicv2_drv.ops = drv_ops;
}

#if defined(CONFIG_UKPLAT_ACPI)
static int acpi_get_gicc(struct _gic_dev *g)
{
	union {
		struct acpi_madt_gicc *gicc;
		struct acpi_subsdt_hdr *h;
	} m;
	struct acpi_madt *madt;
	__sz off, len;

	madt = acpi_get_madt();
	UK_ASSERT(madt);

	/* In ACPI all GICCs' base address must be the same */
	len = madt->hdr.tab_len - sizeof(*madt);
	for (off = 0; off < len; off += m.h->len) {
		m.h = (struct acpi_subsdt_hdr *)(madt->entries + off);

		if (m.h->type != ACPI_MADT_GICC)
			continue;

		/* If GICv3/4 this field is 0 */
		if (!m.gicc->paddr)
			return -ENOTSUP;

		g->cpuif_mem_addr = m.gicc->paddr;
		g->cpuif_mem_size = GICC_MEM_SZ;

		return 0;
	}

	return -ENOENT;
}

static int gicv2_do_probe(void)
{
	int rc;

	rc = acpi_get_gicc(&gicv2_drv);
	if (unlikely(rc < 0))
		return rc;

	rc = acpi_get_gicd(&gicv2_drv);
	if (unlikely(rc < 0))
		return rc;

	if (unlikely(gicv2_drv.dist_mem_size != GICD_V2_MEM_SZ))
		return -ENOTSUP;

	return 0;
}
#else /* CONFIG_UKPLAT_ACPI */
static int gicv2_do_probe(void)
{
	struct ukplat_bootinfo *bi = ukplat_bootinfo_get();
	int fdt_gic, r;
	void *fdt;

	UK_ASSERT(bi);
	fdt = (void *)bi->dtb;

	/* Currently, we only support 1 GIC per system */
	fdt_gic = fdt_node_offset_by_compatible_list(fdt, -1, gic_device_list);
	if (fdt_gic < 0)
		return -FDT_ERR_NOTFOUND; /* GICv2 not present */

	/* Get address and size of the GIC's register regions */
	r = fdt_get_address(fdt, fdt_gic, 0, &gicv2_drv.dist_mem_addr,
			    &gicv2_drv.dist_mem_size);
	if (unlikely(r < 0)) {
		uk_pr_err("Could not find GICv2 distributor region!\n");
		return r;
	}

	r = fdt_get_address(fdt, fdt_gic, 1, &gicv2_drv.cpuif_mem_addr,
			    &gicv2_drv.cpuif_mem_size);
	if (unlikely(r < 0)) {
		uk_pr_err("Could not find GICv2 cpuif region!\n");
		return r;
	}

	return 0;
}
#endif /* !CONFIG_UKPLAT_ACPI */

/**
 * Probe device tree or ACPI for GICv2
 * NOTE: First time must not be called from multiple CPUs in parallel
 *
 * @param [out] dev receives pointer to GICv2 if available, NULL otherwise
 *
 * @return 0 if device is available, an FDT (FDT_ERR_*) error otherwise
 */
int gicv2_probe(struct _gic_dev **dev)
{
	int rc;

#ifdef CONFIG_HAVE_SMP
	if (gicv2_drv.is_probed) {
		/* GIC is already probed, we don't need to probe again */
		if (gicv2_drv.is_present) {
			*dev = &gicv2_drv;
			return 0;
		}

		*dev = NULL;
		return -FDT_ERR_NOTFOUND;
	}
#endif /* CONFIG_HAVE_SMP */

	gicv2_drv.is_probed = 1;

	rc = gicv2_do_probe();
	if (rc) {
		*dev = NULL;
		return rc;
	}

	uk_pr_info("Found GICv2 on:\n");
	uk_pr_info("\tDistributor  : 0x%lx - 0x%lx\n",
		   gicv2_drv.dist_mem_addr,
		   gicv2_drv.dist_mem_addr + gicv2_drv.dist_mem_size - 1);
	uk_pr_info("\tCPU interface: 0x%lx - 0x%lx\n",
		   gicv2_drv.cpuif_mem_addr,
		   gicv2_drv.cpuif_mem_addr + gicv2_drv.cpuif_mem_size - 1);

	/* GICv2 is present */
	gicv2_drv.is_present = 1;
	gicv2_set_ops();

	*dev = &gicv2_drv;
	return 0;
}
